import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const sourceDir = path.join(root, 'governance', 'rules');
const targetDir = path.join(root, '.cursor', 'rules');

const map = [
  ['source-of-truth.md', '00-source-of-truth.mdc', 'Global source of truth rule for Sajtmaskin Next.'],
  ['naming-contract.md', '01-naming-contract.mdc', 'Canonical naming rules.'],
  ['llm-flow-contract.md', '02-llm-flow-contract.mdc', 'LLM flow and generation lane rules.'],
  ['policy-json-first.md', '03-policy-json-first.mdc', 'JSON policy must be changed before code duplicates policy.'],
  ['repo-boundaries.md', '04-repo-boundaries.mdc', 'Folder ownership and import boundary rules.'],
  ['quality-standard-9of10.md', '05-quality-standard-9of10.mdc', 'World-class-lite quality standard.']
];

fs.mkdirSync(targetDir, { recursive: true });
for (const [sourceName, targetName, description] of map) {
  const sourcePath = path.join(sourceDir, sourceName);
  const targetPath = path.join(targetDir, targetName);
  const body = fs.readFileSync(sourcePath, 'utf8').trim();
  const content = `---\ndescription: ${description}\nglobs: *\nalwaysApply: true\n---\n\n<!-- Mirrored from governance/rules/${sourceName}. Edit governance, then run npm run rules:sync. -->\n\n${body}\n`;
  fs.writeFileSync(targetPath, content, 'utf8');
}

console.log(`[rules:sync] mirrored ${map.length} rules into .cursor/rules`);
