import fs from 'node:fs';
import path from 'node:path';

const root = process.cwd();
const policiesDir = path.join(root, 'governance', 'policies');

function readJson(name) {
  const file = path.join(policiesDir, name);
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function assert(condition, message) {
  if (!condition) throw new Error(message);
}

const pageQuality = readJson('page-quality-traits.v1.json');
assert(pageQuality.traits.length === 10, 'page-quality-traits must contain exactly 10 traits');
const traitIds = new Set(pageQuality.traits.map((trait) => trait.id));
assert(traitIds.size === pageQuality.traits.length, 'page-quality-traits contains duplicate trait ids');
const weightTotal = pageQuality.traits.reduce((sum, trait) => sum + trait.weight, 0);
assert(weightTotal === 100, `page-quality-traits weights must total 100, got ${weightTotal}`);

const llmFlow = readJson('llm-flow-concepts.v1.json');
const phaseIds = new Set(llmFlow.phases.map((phase) => phase.id));
assert(phaseIds.size === llmFlow.phases.length, 'llm-flow-concepts contains duplicate phase ids');
assert(JSON.stringify(llmFlow.canonicalFlow) === JSON.stringify(llmFlow.phases.sort((a, b) => a.order - b.order).map((phase) => phase.id)), 'canonicalFlow must match phases sorted by order');

const naming = readJson('naming-dictionary.v1.json');
const names = new Set(naming.terms.map((term) => term.canonical));
assert(names.size === naming.terms.length, 'naming-dictionary contains duplicate canonical terms');

const boundaries = readJson('repo-boundaries.v1.json');
const paths = new Set(boundaries.boundaries.map((boundary) => boundary.path));
assert(paths.size === boundaries.boundaries.length, 'repo-boundaries contains duplicate paths');

console.log('[governance:validate] OK');
