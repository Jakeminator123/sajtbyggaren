# apps/web

UI shell only.

Owns:
- routes
- visual application shell
- forms and user events
- browser state

Does not own:
- LLM prompts
- quality trait truth
- preview runtime implementation
- generation lifecycle decisions
