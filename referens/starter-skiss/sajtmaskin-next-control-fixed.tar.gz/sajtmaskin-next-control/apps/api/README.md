# apps/api

API/auth/transport boundary.

Owns:
- route handlers
- auth boundary
- request validation
- response contracts

Does not own:
- prompt wording
- quality trait weights
- UI state
