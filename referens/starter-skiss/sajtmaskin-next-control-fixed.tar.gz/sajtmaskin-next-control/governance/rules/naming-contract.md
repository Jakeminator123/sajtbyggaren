# Naming contract

Use canonical names. Do not create synonyms because they feel nicer in the moment.

Required canonical terms:
- Site Brief
- Intent Resolution
- Policy Resolution
- Scaffold Resolution
- Generation Package
- Codegen
- Mechanical Autofix
- LLM Repair
- Preview Runtime
- Quality Evaluation
- Promotion

Do not use VM, sandbox, StackBlitz, or Fly as product-wide terms. Use Preview Runtime, then adapter names only when you discuss the implementation.
