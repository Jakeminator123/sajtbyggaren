# Source of truth rule

1. JSON policies in `governance/policies` are truth.
2. JSON schemas in `governance/schemas` define the contract.
3. Docs explain decisions; docs do not override JSON or code.
4. Code should load policy through `packages/policies` instead of copying constants.
5. New product terms must be added to `governance/policies/naming-dictionary.v1.json` before they spread.
6. New LLM-flow phases must be added to `governance/policies/llm-flow-concepts.v1.json` before code or docs reference them.
