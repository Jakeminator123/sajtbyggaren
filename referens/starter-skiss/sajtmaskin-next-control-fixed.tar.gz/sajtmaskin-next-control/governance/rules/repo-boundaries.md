# Repo boundaries

Every folder has one job.

- `apps/web`: UI only.
- `apps/api`: HTTP/auth/transport only.
- `packages/generation`: LLM flow and codegen only.
- `packages/builder`: builder lifecycle and promotion only.
- `packages/preview-runtime`: preview execution abstraction only.
- `packages/policies`: policy loading only.
- `packages/shared`: primitive shared types only.
- `tests/evals`: quality proof and regression checks only.

Before adding a new cross-cutting folder, update `governance/policies/repo-boundaries.v1.json`.
