# Policy JSON first

The ten page quality traits live only in `governance/policies/page-quality-traits.v1.json`.

Do not duplicate trait weights in prompts, docs, tests, or TypeScript constants.

If generation quality changes, update policy first, then prompt composition, then evals.

Quality gate target: 9.0/10. Promotion gate: 8.6/10, with no blocking trait below 7.5.
