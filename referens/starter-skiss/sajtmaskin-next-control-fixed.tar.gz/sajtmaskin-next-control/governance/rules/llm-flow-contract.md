# LLM flow contract

The only allowed generation flow is the canonical flow in `governance/policies/llm-flow-concepts.v1.json`.

No feature may create a second init path, hidden prompt path, or alternate generation lane without updating that JSON first.

A codegen call must receive a complete Generation Package. If a signal is not in the Generation Package, codegen should not rely on it.

Mechanical Autofix always runs before LLM Repair. LLM Repair must be targeted and must not perform a full rewrite unless a human explicitly asks for it.
