# Quality standard: 9 of 10

The project target is not random wow. It is serious business website quality.

A generated page should be:
1. business-specific,
2. visually ordered,
3. conversion-clear,
4. content-specific,
5. trustworthy,
6. responsive,
7. accessible,
8. reasonably fast,
9. polished in interactions,
10. technically correct.

These are not prose-only goals. They map to `page-quality-traits.v1.json` and must be measured by evals before Promotion.
