# Governance

This folder owns the control layer of Sajtmaskin Next.

- `policies`: JSON truth.
- `schemas`: contract for JSON truth.
- `rules`: human-editable rules mirrored to `.cursor/rules`.
- `decisions`: short architecture decisions.

Do not scatter this logic across prompts, UI labels, scripts, and docs.
