# ADR 0002: single LLM flow

## Decision

Sajtmaskin Next has one canonical generation lane from Raw Prompt to Promotion.

## Reason

Multiple init paths make the product difficult to reason about and create name overlap.

## Consequence

New phases require a policy update before implementation.
