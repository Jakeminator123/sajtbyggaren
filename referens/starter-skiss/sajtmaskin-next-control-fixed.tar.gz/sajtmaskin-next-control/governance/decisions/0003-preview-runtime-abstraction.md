# ADR 0003: Preview Runtime abstraction

## Decision

The product term is Preview Runtime. StackBlitz, local, Fly, or VM are adapters.

## Reason

The runtime technology may change. The product architecture should not be renamed every time the execution backend changes.

## Consequence

Runtime-specific code belongs in `packages/preview-runtime`.
