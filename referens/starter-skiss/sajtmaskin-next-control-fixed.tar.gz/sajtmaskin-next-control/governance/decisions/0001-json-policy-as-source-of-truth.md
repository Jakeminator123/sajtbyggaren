# ADR 0001: JSON policy as source of truth

## Decision

Page quality traits, LLM-flow concepts, naming, and repo boundaries are stored as JSON policies under `governance/policies`.

## Reason

The old project became hard to control partly because important concepts were duplicated across docs, prompts, code, branches, and plans. JSON policy gives one editable truth.

## Consequence

Prompt composition, evals, docs, and Cursor rules should derive from or reference policy instead of copying it.
