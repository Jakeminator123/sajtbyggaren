# tests/evals

This folder should prove that generated sites meet the quality target.

Minimum future eval set:

1. local carpenter
2. dental clinic
3. law firm
4. gym / personal trainer
5. restaurant
6. cleaning company
7. real estate agent
8. SaaS landing page
9. dog daycare
10. ecommerce boutique

Score every prompt using the ten trait ids from `page-quality-traits.v1.json`.
