# packages/generation

Owns the canonical LLM flow phases that require generation logic:

- Site Brief
- Intent Resolution
- Scaffold Resolution
- Generation Package
- Codegen
- LLM Repair

It must read policy from `packages/policies` and must not duplicate quality trait weights.
