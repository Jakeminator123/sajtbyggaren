# packages/builder

Owns builder lifecycle:

- draft version state
- mechanical autofix coordination
- repair availability
- promotion
- user-facing build status

It must not contain raw LLM prompt wording.
