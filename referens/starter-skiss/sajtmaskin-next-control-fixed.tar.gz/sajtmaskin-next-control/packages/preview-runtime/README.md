# packages/preview-runtime

Owns the Preview Runtime abstraction.

Do not leak adapter names such as StackBlitz or VM into product-wide naming. Use adapter names only inside this package.
