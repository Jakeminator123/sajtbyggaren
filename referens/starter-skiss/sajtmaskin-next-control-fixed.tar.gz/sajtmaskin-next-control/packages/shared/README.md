# packages/shared

Shared primitive types only. No product policy. No prompts. No runtime adapters.
