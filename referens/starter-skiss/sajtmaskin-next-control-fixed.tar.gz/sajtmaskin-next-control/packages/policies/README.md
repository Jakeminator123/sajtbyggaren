# packages/policies

Typed access layer for governance JSON.

Production code should import policy through this package instead of reading random JSON files directly.
