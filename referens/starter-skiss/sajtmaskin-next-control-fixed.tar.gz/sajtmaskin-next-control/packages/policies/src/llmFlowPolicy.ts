import { loadGovernancePolicy } from './loadPolicy';

export interface LlmFlowPhase {
  id: string;
  order: number;
  canonicalName: string;
  purpose: string;
  inputArtifacts: string[];
  outputArtifacts: string[];
  ownerPackage: string;
  allowedToCallLLM: boolean;
  mustNotDo: string[];
}

export interface LlmFlowPolicy {
  policyId: string;
  version: number;
  canonicalFlow: string[];
  phases: LlmFlowPhase[];
}

export function loadLlmFlowPolicy(): LlmFlowPolicy {
  return loadGovernancePolicy<LlmFlowPolicy>('llm-flow-concepts.v1.json');
}
