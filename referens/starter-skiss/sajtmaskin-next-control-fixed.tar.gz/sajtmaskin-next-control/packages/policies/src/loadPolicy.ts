import fs from 'node:fs';
import path from 'node:path';

export function loadGovernancePolicy<T>(policyFileName: string): T {
  const root = process.cwd();
  const filePath = path.join(root, 'governance', 'policies', policyFileName);
  const raw = fs.readFileSync(filePath, 'utf8');
  return JSON.parse(raw) as T;
}
