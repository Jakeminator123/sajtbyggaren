import { loadGovernancePolicy } from './loadPolicy';

export interface PageQualityTrait {
  id: string;
  name: string;
  weight: number;
  ownerPackage: string;
  definition: string;
  positiveSignals: string[];
  negativeSignals: string[];
  checkMethods: string[];
}

export interface PageQualityPolicy {
  policyId: string;
  version: number;
  qualityTarget: {
    scoreScale: string;
    targetScore: number;
    gateScore: number;
    blockBelow: number;
  };
  traits: PageQualityTrait[];
}

export function loadPageQualityPolicy(): PageQualityPolicy {
  return loadGovernancePolicy<PageQualityPolicy>('page-quality-traits.v1.json');
}
