# Terminology

Human-readable mirror of `governance/policies/naming-dictionary.v1.json`.

## Canonical terms

- Sajtmaskin Next
- Site Brief
- Intent Resolution
- Policy Resolution
- Scaffold Resolution
- Generation Package
- Codegen
- Mechanical Autofix
- LLM Repair
- Preview Runtime
- Quality Evaluation
- Promotion

## Forbidden pattern

Do not use the same word for two lifecycle stages. For example, `save`, `preview`, and `promote` must not mean the same thing.
