# LLM flow for Sajtmaskin Next

The canonical flow is defined in:

`governance/policies/llm-flow-concepts.v1.json`

## Canonical lane

Raw Prompt -> Site Brief -> Intent Resolution -> Policy Resolution -> Scaffold Resolution -> Generation Package -> Codegen -> Mechanical Autofix -> LLM Repair -> Preview Runtime -> Quality Evaluation -> Promotion

## Design principle

The system should feel simple because there is one lane. Complexity is allowed inside a phase, not between competing init paths.

## Hard rules

- No hidden init path.
- No codegen without a Generation Package.
- No promotion without Quality Evaluation.
- No runtime-specific naming leak. Use Preview Runtime, then adapter names.
- No new phase name unless it is added to the LLM flow policy.
