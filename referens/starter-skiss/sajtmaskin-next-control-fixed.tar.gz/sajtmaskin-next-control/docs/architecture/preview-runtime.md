# Preview Runtime

Use `Preview Runtime` as the product concept.

Adapters may include:

- `StackBlitzPreviewRuntime`
- `LocalPreviewRuntime`
- `FlyPreviewRuntime`
- `VmPreviewRuntime`

The adapter must not own generation logic. It receives files and runtime config, then returns a preview session.

This prevents StackBlitz, Fly, VM, sandbox, and local dev terms from spreading through the whole codebase.
