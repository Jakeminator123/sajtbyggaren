# Page quality policy

The ten page quality traits are defined in:

`governance/policies/page-quality-traits.v1.json`

That file is the source of truth for generation guidance, eval scoring, and promotion gates.

## Target

- Target: 9.0/10
- Gate: 8.6/10
- Block below: 7.5/10 on any trait

## Workflow

1. Change JSON policy.
2. Run `npm run governance:validate`.
3. Update prompt composition to read the policy.
4. Update evals to score the same trait ids.
5. Only then adjust UI wording.

Never start by editing prompt prose in isolation.
