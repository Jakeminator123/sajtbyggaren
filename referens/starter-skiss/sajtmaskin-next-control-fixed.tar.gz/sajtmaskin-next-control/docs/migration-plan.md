# Migration plan

This starter should become the clean shell before old code is imported.

## Phase 1: lock governance

- Keep `.cursor/rules` and `governance/rules` in sync.
- Validate JSON policies.
- Decide baseline commit for generation core.

## Phase 2: import generation core

- Import prompt/core generation code only.
- Replace scattered quality words with `page-quality-traits.v1.json`.
- Replace scattered flow words with `llm-flow-concepts.v1.json`.

## Phase 3: import builder lifecycle

- Import builder state and promotion logic.
- Keep preview execution behind `PreviewRuntime`.

## Phase 4: import preview adapter

- Start with StackBlitz if that is the desired future.
- Keep local runtime for tests.
- Do not rename product concepts to StackBlitz concepts.

## Phase 5: eval gate

- Build smoke tests.
- Add 5-10 representative company prompts.
- Score against the ten quality traits.

## Phase 6: UI/API

- Build UI around the stable lifecycle.
- Expose only one clear init path to the user.
