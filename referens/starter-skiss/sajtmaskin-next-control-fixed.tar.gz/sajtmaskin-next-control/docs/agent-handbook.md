# Agent handbook

Before changing code, read:

1. `.cursor/rules/00-source-of-truth.mdc`
2. `governance/policies/naming-dictionary.v1.json`
3. `governance/policies/llm-flow-concepts.v1.json`
4. `governance/policies/repo-boundaries.v1.json`
5. `governance/policies/page-quality-traits.v1.json`

## Agent workflow

1. Identify the folder owner.
2. Check whether a term/policy already exists.
3. Change JSON first if the concept affects more than one package.
4. Keep commits small and named by phase.
5. Run `npm run governance:validate` before handoff.
