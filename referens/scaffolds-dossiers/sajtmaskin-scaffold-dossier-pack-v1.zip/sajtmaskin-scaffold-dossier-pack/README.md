# Sajtmaskin Scaffold + Dossier Pack v1

Det här paketet är en liten, konkret startpunkt för nya Sajtmaskin:

- ett komplett scaffold: `local-service-business`
- två återanvändbara dossierer: `contact-form` och `reviews`
- policyfiler för scaffold-/dossier-val
- typkontrakt i TypeScript
- valideringsscript
- jämförelsedoc mot en tänkt `app-ecommerce`-scaffold

## Grundidé

```txt
Scaffold = sajtgrammatik + route-familjer + sektionsordning + kvalitetskontrakt
Dossier  = återanvändbar capability/byggkloss med tydlig aktivering och kontrakt
Variant  = visuell riktning inom scaffoldet
Policy   = ändringsbar sanning för val, kvalitet och constraints
```

Dossierer är generella byggklossar, men de ska inte injiceras överallt automatiskt. Alla scaffolds ska kunna konsumera samma dossier-interface, men varje dossier måste aktiveras via brief + policy + scaffold-kompatibilitet.

## Viktiga filer

```txt
packages/generation/scaffolds/local-service-business/scaffold.json
packages/generation/scaffolds/local-service-business/routes.json
packages/generation/scaffolds/local-service-business/sections.json
packages/generation/scaffolds/local-service-business/quality-contract.json
packages/generation/scaffolds/local-service-business/compatible-dossiers.json
packages/generation/scaffolds/local-service-business/selection-profile.json
packages/generation/dossiers/hybrid/contact-form/dossier.json
packages/generation/dossiers/soft/reviews/dossier.json
docs/SCAFFOLDS_VS_DOSSIERS.md
docs/LOCAL_SERVICE_VS_APP_ECOMMERCE.md
```

## Validera

```bash
node scripts/validate-pack.mjs
```

Förväntat resultat:

```txt
[validate-pack] OK
```
