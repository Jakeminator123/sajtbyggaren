// Minimal illustrative logic. In real Sajtmaskin this should be combined with
// embeddings + a small LLM reranker + policy gates + trace logging.

type CompatibilityList = {
  required: string[];
  recommended: string[];
  conditional: Array<{ id: string; when: string }>;
  allowedButUsuallyNotDefault: string[];
  disallowedByDefault: string[];
};

type Dossier = {
  id: string;
  class: 'soft' | 'hybrid' | 'hard';
  portableAcrossScaffolds: boolean;
};

export function getDossierCompatibility(
  dossier: Dossier,
  compatibility: CompatibilityList,
): 'required' | 'recommended' | 'conditional' | 'allowed' | 'blocked' | 'unknown' {
  if (compatibility.required.includes(dossier.id)) return 'required';
  if (compatibility.recommended.includes(dossier.id)) return 'recommended';
  if (compatibility.conditional.some((item) => item.id === dossier.id)) return 'conditional';
  if (compatibility.allowedButUsuallyNotDefault.includes(dossier.id)) return 'allowed';
  if (compatibility.disallowedByDefault.includes(dossier.id)) return 'blocked';
  return dossier.portableAcrossScaffolds ? 'unknown' : 'blocked';
}

export function shouldAutoSelectDossier(args: {
  compatibility: ReturnType<typeof getDossierCompatibility>;
  dossierClass: Dossier['class'];
  explicitUserNeed: boolean;
  generationMode: 'design' | 'integration';
}) {
  if (args.compatibility === 'blocked') return false;
  if (args.compatibility === 'required') return true;
  if (args.dossierClass === 'hard' && !args.explicitUserNeed) return false;
  if (args.compatibility === 'recommended') return true;
  if (args.compatibility === 'conditional') return args.explicitUserNeed;
  return false;
}
