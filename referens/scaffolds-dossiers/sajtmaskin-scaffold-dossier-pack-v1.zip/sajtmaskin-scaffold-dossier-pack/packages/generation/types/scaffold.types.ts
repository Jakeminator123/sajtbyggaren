export type ScaffoldId = string;
export type DossierId = string;

export interface ScaffoldDefinition {
  id: ScaffoldId;
  version: string;
  label: string;
  description: string;
  buildIntent: string[];
  bestFor: string[];
  notFor: string[];
  supportsSinglePage: boolean;
  supportsMultiPage: boolean;
  supportsAppFeatures: boolean;
  defaultPageCount: number;
  minPageCount: number;
  maxPageCount: number;
}

export interface ScaffoldRoute {
  id: string;
  path: string;
  required?: boolean;
  routeFamily: string;
  purpose: string;
  when?: string;
}

export interface ScaffoldSelectionTrace {
  selectedScaffold: ScaffoldId;
  confidence: number;
  method: 'embedding-plus-small-llm-rerank' | 'fallback';
  candidates: Array<{
    id: ScaffoldId;
    embeddingScore?: number;
    rerankScore?: number;
    reason?: string;
  }>;
  rejected?: Array<{
    id: ScaffoldId;
    reason: string;
  }>;
}
