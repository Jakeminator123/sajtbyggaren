export type DossierClass = 'soft' | 'hybrid' | 'hard';
export type GenerationMode = 'design' | 'integration';

export interface DossierDefinition {
  id: string;
  version: string;
  class: DossierClass;
  label: string;
  purpose: string;
  portableAcrossScaffolds: boolean;
  bestFor: string[];
  activation: {
    selectionMode: string;
    requiresUserMention: boolean;
    defaultWhen: string[];
    blockWhen?: string[];
  };
  scaffoldRealizations: Record<string, {
    typicalRoutes: string[];
    typicalSections: string[];
    purpose: string;
    fields?: string[];
    contentStyle?: string;
  }>;
  codeContract: string[];
  qualityChecks: string[];
}

export interface SelectedDossier {
  id: string;
  class: DossierClass;
  reason: string;
  mode: GenerationMode;
  affectsRoutes: string[];
  affectsSections: string[];
  realizationForScaffold: string;
}
