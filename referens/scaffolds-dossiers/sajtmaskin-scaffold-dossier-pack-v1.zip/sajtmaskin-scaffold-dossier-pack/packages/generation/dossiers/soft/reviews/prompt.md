# Dossier prompt: reviews

Add realistic social proof that matches the scaffold context.

## Must

- Make the reviews specific to the business, product or app context.
- Use credible details without overclaiming.
- Avoid repeated generic praise.
- Do not create regulated or medical/legal/financial claims unless policy allows it.

## Scaffold-specific realization

- `local-service-business`: reviews prove reliability, fast response, cleanliness, price clarity or trust.
- `app-ecommerce`: reviews usually attach to products, shipping, support or store trust.
- `saas-product`: reviews usually attach to outcomes, workflow improvements or customer logos.
