# Dossier prompt: contact-form

Add a contact or lead-capture form that matches the selected scaffold and route plan.

## Must

- Use accessible labels.
- Include useful fields for the scaffold context.
- Include a visible success state.
- Include basic validation behavior.
- Avoid hardcoded secrets.
- In design mode, mock submit is allowed.

## Scaffold-specific realization

- `local-service-business`: quote request/contact form, usually on `/kontakt`, with phone field.
- `app-ecommerce`: support/contact form, usually not part of checkout. Include order number only if support context exists.
- `saas-product`: demo request or sales contact form.
