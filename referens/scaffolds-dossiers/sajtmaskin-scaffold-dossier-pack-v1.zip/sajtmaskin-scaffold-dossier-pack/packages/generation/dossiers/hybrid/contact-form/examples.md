# contact-form examples

## Local service business

Fields: name, email, phone, message/service need.
CTA copy: "Begär offert" or "Boka kostnadsfri rådgivning".

## App ecommerce

Fields: name, email, order number, message.
CTA copy: "Kontakta support".

## SaaS

Fields: name, work email, company, message.
CTA copy: "Boka demo".
