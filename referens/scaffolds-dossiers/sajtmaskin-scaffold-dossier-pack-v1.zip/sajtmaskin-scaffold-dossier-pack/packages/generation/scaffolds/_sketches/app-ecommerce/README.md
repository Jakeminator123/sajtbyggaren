# app-ecommerce sketch

This is intentionally not a full scaffold in this pack. It exists to clarify the contrast with `local-service-business`.

## Intended grammar

```txt
app-ecommerce = product catalogue + transaction flow + account/order/support states
```

## Likely route families

```txt
home
product-index
product-detail
cart
checkout
account
orders
support
returns
```

## Likely compatible dossiers

```txt
product-reviews
cart
checkout
payments
auth
support-form
newsletter
inventory-status
```

## Main distinction

A local service site wants trust and contact. An app-ecommerce site wants product evaluation, purchase flow and post-purchase support.
