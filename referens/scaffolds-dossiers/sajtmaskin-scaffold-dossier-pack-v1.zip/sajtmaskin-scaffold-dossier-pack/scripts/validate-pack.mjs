import fs from 'node:fs';
import path from 'node:path';

const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..');

function readJson(rel) {
  const abs = path.join(root, rel);
  return JSON.parse(fs.readFileSync(abs, 'utf8'));
}

function assert(condition, message) {
  if (!condition) {
    throw new Error(message);
  }
}

const scaffold = readJson('packages/generation/scaffolds/local-service-business/scaffold.json');
const routes = readJson('packages/generation/scaffolds/local-service-business/routes.json');
const sections = readJson('packages/generation/scaffolds/local-service-business/sections.json');
const compat = readJson('packages/generation/scaffolds/local-service-business/compatible-dossiers.json');
const registry = readJson('packages/generation/dossiers/registry.json');
const contact = readJson('packages/generation/dossiers/hybrid/contact-form/dossier.json');
const reviews = readJson('packages/generation/dossiers/soft/reviews/dossier.json');
const scaffoldPolicy = readJson('governance/policies/scaffold-selection.v1.json');

assert(scaffold.id === 'local-service-business', 'Wrong scaffold id');
assert(routes.defaultRoutes.some((r) => r.path === '/kontakt'), 'Missing contact route');
assert(sections.sectionFamilies.hero.requiredOn.includes('home'), 'Hero should be required on home');
assert(compat.recommended.includes('contact-form'), 'contact-form should be recommended');
assert(compat.recommended.includes('reviews'), 'reviews should be recommended');
assert(registry.dossiers.length === 2, 'Expected exactly two dossier registry entries');
assert(contact.class === 'hybrid', 'contact-form should be hybrid');
assert(reviews.class === 'soft', 'reviews should be soft');
assert(scaffoldPolicy.wordMatching.mayDirectlySelectScaffold === false, 'Word matching must not select scaffold directly');

console.log('[validate-pack] OK');
