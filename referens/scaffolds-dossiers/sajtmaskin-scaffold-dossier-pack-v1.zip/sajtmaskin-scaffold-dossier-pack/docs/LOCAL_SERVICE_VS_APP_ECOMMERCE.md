# Local Service Business vs App Ecommerce

Det här paketet innehåller ett komplett `local-service-business`-scaffold. `app-ecommerce` finns här som jämförelsebegrepp, inte som full scaffold.

## Huvudskillnad

```txt
local-service-business = förtroende + serviceförklaring + lokal konvertering
app-ecommerce          = produktflöde + transaktion + konto/order/support
```

## Extra sidor i local-service-business

Extra sidor är oftast **trust-, SEO- och konverteringssidor**.

Exempel:

```txt
/tjanster/[service]  → djupare sida för en tjänst
/omraden             → lokal SEO / serviceområden
/akut                → akut CTA för snabb hjälp
/referenser          → projekt, före/efter, kundbevis
/fragor-svar         → invändningar, prisfrågor, trygghet
```

De finns för att svara på:

```txt
Kan jag lita på företaget?
Gör de det jag behöver?
Jobbar de i mitt område?
Hur snabbt kan jag få hjälp?
Hur tar jag kontakt?
```

## Extra sidor i app-ecommerce

Extra sidor är oftast **produkt-, transaktions- och app-state-sidor**.

Exempel:

```txt
/produkter                 → produktkatalog
/produkter/[productSlug]   → produktdetalj
/cart                      → varukorg
/checkout                  → checkout
/account                   → konto
/account/orders            → orderhistorik
/support                   → supportflöde
/returns                   → returpolicy
```

De finns för att svara på:

```txt
Vad kan jag köpa?
Vilken produkt passar?
Vad finns i varukorgen?
Hur betalar jag?
Var är min order?
Hur får jag support?
```

## Samma dossier, olika realisering

### contact-form

`local-service-business`:

```txt
/kontakt
Offertförfrågan, telefon, servicebehov, meddelande.
```

`app-ecommerce`:

```txt
/support eller /contact
Supportärende, ordernummer, e-post, meddelande.
```

### reviews

`local-service-business`:

```txt
Trust-sektion på startsida/om oss. Fokus: snabbhet, trygghet, utfört jobb.
```

`app-ecommerce`:

```txt
Produktrecensioner eller butikstrust. Fokus: produkt, leverans, support, köpupplevelse.
```

## Slutsats

Dossierer är portabla, men deras **realisering** måste vara scaffold-specifik.

Annars får du samma problem som tidigare: samma namn används i flera sammanhang men betyder olika saker.
