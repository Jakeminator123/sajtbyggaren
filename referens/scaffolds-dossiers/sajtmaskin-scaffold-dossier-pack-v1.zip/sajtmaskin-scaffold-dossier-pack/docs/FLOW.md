# Selection flow

```mermaid
flowchart TD
    A[Structured Site Brief] --> B[Scaffold Embedding Query]
    B --> C[Top-K Scaffold Candidates]
    C --> D[Small LLM Reranker]
    D --> E[Policy Gate]
    E --> F[Selected Scaffold]

    F --> G[Compatible Dossiers]
    A --> H[Dossier Embedding Query]
    H --> I[Top-K Dossier Candidates]
    G --> J[Compatibility Filter]
    I --> J
    J --> K[Small LLM Dossier Rerank]
    K --> L[Soft/Hybrid/Hard Policy Gate]
    L --> M[Selected Dossiers]

    F --> N[Route Plan]
    M --> N
    N --> O[Generation Package]
```

## Key rule

Word matching may create weak hints, but cannot directly select the scaffold.
