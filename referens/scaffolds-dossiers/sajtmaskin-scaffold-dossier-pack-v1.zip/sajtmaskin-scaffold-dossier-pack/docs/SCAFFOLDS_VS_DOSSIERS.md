# Scaffolds vs dossierer

## Scaffold

Ett scaffold är sajtens **grammatik**.

Det bestämmer:

- vilken typ av sajt som byggs
- vilka route-familjer som är rimliga
- vilken sektionslogik som passar
- vilka kvalitetskrav som är extra viktiga
- vilka dossierer som är rekommenderade, villkorade eller blockerade

Exempel: `local-service-business`.

Det betyder inte bara "en företagssida". Det betyder en sajt där trust, lokal relevans, serviceförklaring och offert/kontakt är kärnan.

## Dossier

En dossier är en återanvändbar **capability-modul**.

Den kan innehålla:

- aktiveringsregler
- prompt-instruktioner
- kodkontrakt
- env-/integrationskrav
- route-/sektionspåverkan
- scaffold-specifika realiseringar
- quality checks

Exempel: `contact-form`.

Samma dossier kan användas i flera scaffolds, men den realiseras olika:

```txt
local-service-business → offert-/kontaktformulär på /kontakt
app-ecommerce         → support-/orderfrågeformulär på /support eller /contact
saas-product          → demo-/salesformulär på /demo eller /contact
```

## Missförståndet att undvika

Dossierer är generella byggklossar, men inte globala standardsektioner som alltid ska injiceras.

Rätt modell:

```txt
Alla scaffolds kan konsumera samma dossier-interface.
Men varje scaffold + policy + brief avgör om dossiern ska användas.
```

Fel modell:

```txt
Alla dossierer kan stoppas in överallt utan begränsning.
```

## Ansvarsfördelning

| Del | Ansvar |
|---|---|
| Brief | Vad användaren vill bygga |
| Policy | Vad Sajtmaskin räknar som kvalitet och tillåtet |
| Scaffold | Vilken sajtgrammatik som ska användas |
| Variant | Vilket visuellt uttryck scaffoldet får |
| Dossier | Vilka extra capabilities/byggklossar som behövs |
| BuildSpec | Hur strikt generation/finalize/quality gate ska vara |
